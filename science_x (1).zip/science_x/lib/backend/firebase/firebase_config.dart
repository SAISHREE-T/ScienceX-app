import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDh9DfhX4Jexn0MA5GIi2xNsPau5gkvJ80",
            authDomain: "fir-sciencex.firebaseapp.com",
            projectId: "fir-sciencex",
            storageBucket: "fir-sciencex.appspot.com",
            messagingSenderId: "340518116078",
            appId: "1:340518116078:web:40731e882125199a3171ff",
            measurementId: "G-4LF17LR5VS"));
  } else {
    await Firebase.initializeApp();
  }
}
