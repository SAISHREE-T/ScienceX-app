// Export pages
export '/pages/splash_screen/splash_screen_widget.dart' show SplashScreenWidget;
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/register/register_widget.dart' show RegisterWidget;
export '/pages/edit_profile/edit_profile_widget.dart' show EditProfileWidget;
export '/pages/my_profile/my_profile_widget.dart' show MyProfileWidget;
export '/pages/change_password/change_password_widget.dart'
    show ChangePasswordWidget;
export '/muskpage/muskpage_widget.dart' show MuskpageWidget;
export '/pages/renewable2/renewable2_widget.dart' show Renewable2Widget;
export '/pages/home/home_widget.dart' show HomeWidget;
export '/pages/tesla_papers/tesla_papers_widget.dart' show TeslaPapersWidget;
export '/pages/spacex/spacex_widget.dart' show SpacexWidget;
