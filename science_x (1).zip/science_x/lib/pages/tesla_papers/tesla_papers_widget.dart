import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'tesla_papers_model.dart';
export 'tesla_papers_model.dart';

class TeslaPapersWidget extends StatefulWidget {
  const TeslaPapersWidget({Key? key}) : super(key: key);

  @override
  _TeslaPapersWidgetState createState() => _TeslaPapersWidgetState();
}

class _TeslaPapersWidgetState extends State<TeslaPapersWidget> {
  late TeslaPapersModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TeslaPapersModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(_model.unfocusNode),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: Stack(
            children: [
              Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Stack(
                  children: [],
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: FFButtonWidget(
                  onPressed: () async {
                    context.pushNamed('renewable2');
                  },
                  text: 'Button',
                  icon: Icon(
                    Icons.arrow_back_sharp,
                    size: 15.0,
                  ),
                  options: FFButtonOptions(
                    height: 66.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 24.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          fontFamily: 'Outfit',
                          color: Colors.white,
                        ),
                    elevation: 3.0,
                    borderSide: BorderSide(
                      color: Colors.transparent,
                      width: 1.0,
                    ),
                    borderRadius: BorderRadius.circular(0.0),
                  ),
                ),
              ),
            ],
          ),
          title: Text(
            'Renewable energy in Tesla',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding:
                      EdgeInsetsDirectional.fromSTEB(16.0, 16.0, 16.0, 0.0),
                  child: Container(
                    width: double.infinity,
                    height: 768.0,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                    child: Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          12.0, 12.0, 12.0, 12.0),
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              '1. Tesla\'s Sustainability Report 2020 - This report provides an overview of Tesla\'s sustainability initiatives and progress, including its efforts to promote renewable energy. It discusses the company\'s approach to sustainability, its goals and targets, and its performance in areas such as energy usage, greenhouse gas emissions, and water conservation.\n',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: Color(0xFF686868),
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                            ),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(16.0),
                              child: Image.asset(
                                'assets/images/486595.jpg',
                                width: 300.0,
                                height: 200.0,
                                fit: BoxFit.cover,
                              ),
                            ),
                            Text(
                              '\n2. Tesla\'s Renewable Energy Plan - This document outlines Tesla\'s strategy for increasing the use of renewable energy in its operations, including the development of solar and wind farms, the purchase of renewable energy credits, and the implementation of energy efficiency measures.\n\n3. Tesla\'s Gigafactory 1 - This document provides information about Tesla\'s Gigafactory 1, which is a state-of-the-art manufacturing facility that produces lithium-ion batteries for Tesla\'s electric vehicles and energy products. It explains how the Gigafactory is designed to be powered by renewable energy sources, such as solar and geothermal power.\n\n',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: Color(0xFF686868),
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                            ),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(16.0),
                              child: Image.asset(
                                'assets/images/97d10bd4-2573-4536-a435-1c13110bd877.jpeg',
                                width: 300.0,
                                height: 200.0,
                                fit: BoxFit.cover,
                              ),
                            ),
                            Text(
                              '\n\n4. Tesla\'s Autonomous Energy Grid - This document describes Tesla\'s vision for an autonomous energy grid, which would use artificial intelligence and machine learning to optimize the flow of renewable energy between energy producers, consumers, and storage systems. It explains how this system could help to increase the penetration of renewable energy into the grid.\n\n5. Tesla\'s Energy Storage for Renewable Energy Integration - This document discusses the importance of energy storage in integrating renewable energy sources into the grid. It explains how Tesla\'s energy storage products, such as the Powerpack and Powerwall, can help to smooth out fluctuations in renewable energy output and provide a stable source of power.\n\n',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: Color(0xFF686868),
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                            ),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(16.0),
                              child: Image.asset(
                                'assets/images/telsa-solarcity-e1466550091811.webp',
                                width: 300.0,
                                height: 200.0,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
